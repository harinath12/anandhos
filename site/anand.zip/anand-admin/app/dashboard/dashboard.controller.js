angular.module('app')
        .controller('dashboardController', dashboardController);

dashboardController.$inject = ['$scope', '$state', '$rootScope', 'APIURL', '$http', 'ApiService']

function dashboardController($scope, $state, $rootScope, APIURL, $http, ApiService) {
	
}